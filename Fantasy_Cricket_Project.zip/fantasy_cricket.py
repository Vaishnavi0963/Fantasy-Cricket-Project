import sqlite3
import tkinter as tk
from tkinter import messagebox

# Step 1: Create the database and table
def setup_database():
    conn = sqlite3.connect("cricket.db")
    cursor = conn.cursor()
    cursor.execute('''CREATE TABLE IF NOT EXISTS players (
                    id INTEGER PRIMARY KEY,
                    name TEXT,
                    role TEXT,
                    team TEXT,
                    price INTEGER)''')
    
    # Sample Data
    players = [
        ('Virat Kohli', 'Batsman', 'India', 10),
        ('Rohit Sharma', 'Batsman', 'India', 9),
        ('Jasprit Bumrah', 'Bowler', 'India', 9),
        ('Ben Stokes', 'All-Rounder', 'England', 10),
        ('Joe Root', 'Batsman', 'England', 9),
        ('Pat Cummins', 'Bowler', 'Australia', 9),
        ('Steve Smith', 'Batsman', 'Australia', 10),
        ('MS Dhoni', 'Wicketkeeper', 'India', 8)
    ]
    
    cursor.executemany("INSERT INTO players (name, role, team, price) VALUES (?, ?, ?, ?)", players)
    conn.commit()
    conn.close()

# Step 2: Create GUI for Team Selection
def create_gui():
    root = tk.Tk()
    root.title("Fantasy Cricket Team Selection")
    tk.Label(root, text="Select Your Team", font=("Arial", 16)).pack()
    
    # Load players
    conn = sqlite3.connect("cricket.db")
    cursor = conn.cursor()
    cursor.execute("SELECT name, role FROM players")
    players = cursor.fetchall()
    conn.close()
    
    # Display players
    for player in players:
        tk.Label(root, text=f"{player[0]} ({player[1]})").pack()
    
    root.mainloop()

# Run the setup and GUI
setup_database()
create_gui()
