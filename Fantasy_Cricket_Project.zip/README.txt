# Fantasy Cricket Team Selection

## Description
This is a simple Fantasy Cricket Team Selection app using Python's Tkinter for the GUI and SQLite for database storage.

## Features
- Creates a player database with roles.
- Displays players in a GUI.
- Allows users to select their team.

## Requirements
- Python 3
- Tkinter (pre-installed in Python)
- SQLite3 (pre-installed in Python)

## How to Run
1. Extract the ZIP file.
2. Open a terminal or command prompt in the extracted folder.
3. Run the script using:
   ```
   python fantasy_cricket.py
   ```

Enjoy your Fantasy Cricket Team Selection!
